package com.example.myapplication.Client;

import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;

import com.example.myapplication.DataStructure.Duser;
import com.example.myapplication.DataStructure.Item;
import com.example.myapplication.DataStructure.User;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.net.URISyntaxException;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

/**
 * Created by YoungJu on 2017-12-14.
 */

public class Client {
    private String html = "";
    private Handler mHandler;
    private String name;
    private BufferedReader networkReader;
    private BufferedWriter networkWriter;
    private String ip = "210.89.176.134"; // IP
    private int port = 5000; // PORT번호

    private static Client client=null;
    private Socket mSocket;

    private User user;
    private Duser duser;

    private boolean isDuser;

    private boolean wait=false;
    private boolean login=false;

    public static Client getInstance(){ return client; }

    public boolean isUser(){
        if(isDuser) return false;
        else return true;
    }

    public Client(){
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            setSocket(ip,port);
            Log.d("test","socket create");
        } catch(Exception e) {
            e.printStackTrace();
        }
        client=this;
    }

    public void setSocket(String ip, int port) throws IOException, URISyntaxException {
        try {
            mSocket = IO.socket("http://"+ip+":"+port);
            Log.d("test","mSocket Create");
            mSocket.connect();
            Log.d("test","mSocket Connect");
        } catch (Exception e) {
            System.out.println(e);
            e.printStackTrace();
        }
    }
    /*
    login -> id%pw
    Dinfo->배달원 structure 보내기
    Uitem->db에 item 등록
    Items->배달원에게 item 정보 제공
    Comp->배달원과 user item 정보 삭제 후 돈 정보 이동
    Refresh -> 배달원의 struc을 주는데 위치가 추가되니 item들에 위치 정보 추가*/

    public boolean Login(String id,String pw,boolean IsDuser){
//        mSocket.emit("Login","id%pw");//customerLogin
//        mSocket.on("LoginOK",)
        isDuser=IsDuser;
        if(IsDuser){

        }else {
            JSONObject jsonLogin = new JSONObject();
            try {
                jsonLogin.put("id",id);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            try {
                jsonLogin.put("pw",pw);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            wait=true;

            mSocket.emit("customerLogin", jsonLogin);

            Emitter.Listener state1Delivery = new Emitter.Listener(){
                @Override
                public void call(Object... args){
                    wait=false;
                    login=true;
                }
            };
            mSocket.on("customerState1",state1Delivery);
            Emitter.Listener state2Delivery = new Emitter.Listener(){
                @Override
                public void call(Object... args){
                    //args[0]이 전체 데이터를 품은 json 객체
                    wait=false;
                    login=true;

                }
            };
            mSocket.on("customerState2",state2Delivery);
            Emitter.Listener state3Delivery = new Emitter.Listener(){
                @Override
                public void call(Object... args){
                    //args[0]이 전체 데이터를 품은 json 객체
                    wait=false;
                    login=true;

                }
            };
            mSocket.on("customerState3",state3Delivery);
            Emitter.Listener state4Delivery = new Emitter.Listener(){
                @Override
                public void call(Object... args){
                    //args[0]이 전체 데이터를 품은 json 객체
                    wait=false;
                    login=true;
                }
            };
            mSocket.on("customerState4",state4Delivery);
            Emitter.Listener loginFail = new Emitter.Listener(){
                @Override
                public void call(Object... args){
                    wait=false;

                }
            };
            mSocket.on("customerLoginNo",loginFail);
        }
        while(wait);

        return login;
    }
    public void Dinfo(){

    }
    public void Uitem(Item item){}
    public void Comp(){}
    public void Refresh(){}

}
